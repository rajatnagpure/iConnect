These test messages are part of the MIME-tools Perl library:
http://search.cpan.org/~dskoll/MIME-tools-5.502/
